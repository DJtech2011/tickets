// JS logic for ticket form
