# QR Ticketing System
Simple GitHub-based QR ticketing system for school events.